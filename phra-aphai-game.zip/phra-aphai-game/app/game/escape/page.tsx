"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Button from "@/components/Button";
import Bar from "@/components/Bar";
import Screen from "@/components/Screen";
import type {
  DifficultyMode,
  EscapeEntity,
  EscapeEntityType,
  Question,
} from "@/types/game";
import { GAME_CONFIG } from "@/lib/gameConstants";
import { getGameState, saveGameState } from "@/lib/gameStorage";
import { questions } from "@/data/questions";

const LANE_TOP = ["20%", "50%", "80%"];

const DAMAGE_TYPES: EscapeEntityType[] = ["rock", "wave", "shadow"];

const ENTITY_META: Record<
  EscapeEntityType,
  {
    icon: string;
    label: string;
    className: string;
  }
> = {
  rock: {
    icon: "🪨",
    label: "หินใต้น้ำ",
    className: "bg-slate-700 border-slate-300",
  },
  wave: {
    icon: "🌊",
    label: "คลื่นแรง",
    className: "bg-blue-700 border-blue-200",
  },
  shadow: {
    icon: "👁️",
    label: "เงาผีเสื้อสมุทร",
    className: "bg-red-950 border-red-400",
  },
  heal: {
    icon: "💚",
    label: "ไข่มุกฟื้นพลัง",
    className: "bg-emerald-700 border-emerald-200",
  },
  quiz: {
    icon: "❓",
    label: "คำถามวรรณคดี",
    className: "bg-thai-gold border-yellow-100",
  },
};

function isDamageEntity(type: EscapeEntityType) {
  return type === "rock" || type === "wave" || type === "shadow";
}

function getRandomQuestion(): Question {
  return questions[Math.floor(Math.random() * questions.length)];
}

function createEntity(
  id: number,
  modeConfig: (typeof GAME_CONFIG.escape.modes)[DifficultyMode]
): EscapeEntity {
  const roll = Math.random();

  let type: EscapeEntityType;

  if (roll < modeConfig.healChance) {
    type = "heal";
  } else if (roll < modeConfig.healChance + modeConfig.quizChance) {
    type = "quiz";
  } else {
    type = DAMAGE_TYPES[Math.floor(Math.random() * DAMAGE_TYPES.length)];
  }

  let speed = modeConfig.baseSpeed + Math.random() * 3;

  if (type === "shadow") speed += 2.5;
  if (type === "wave") speed += 1.2;
  if (type === "rock") speed -= 0.8;
  if (type === "heal") speed -= 0.5;
  if (type === "quiz") speed -= 0.2;

  return {
    id,
    lane: Math.floor(Math.random() * 3),
    x: 110,
    speed,
    type,
  };
}

export default function EscapeGamePage() {
  const router = useRouter();

  const [difficultyMode, setDifficultyMode] = useState<DifficultyMode>("normal");

  const modeConfig = GAME_CONFIG.escape.modes[difficultyMode];

  const [phase, setPhase] = useState<
    "setup" | "playing" | "quiz" | "won" | "lost"
  >("setup");

  const [playerLane, setPlayerLane] = useState(1);
  const [hp, setHp] = useState<number>(modeConfig.maxHP);
  const [distance, setDistance] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [obstacles, setObstacles] = useState<EscapeEntity[]>([]);
  const [activeQuestion, setActiveQuestion] = useState<Question | null>(null);
  const [statusText, setStatusText] = useState(
    "เลือกโหมดความยากก่อนเริ่มหนีถ้ำสมุทร"
  );
  const [isHit, setIsHit] = useState(false);

  const playerLaneRef = useRef(playerLane);
  const hpRef = useRef(hp);
  const scoreRef = useRef(score);
  const comboRef = useRef(combo);
  const phaseRef = useRef(phase);
  const obstacleIdRef = useRef(1);

  const hitEntityIdsRef = useRef<Set<number>>(new Set());
  const dodgedEntityIdsRef = useRef<Set<number>>(new Set());

  const gameLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const spawnLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const redirectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const finishGame = useCallback(
    (isWin: boolean) => {
      if (phaseRef.current === "won" || phaseRef.current === "lost") return;

      const nextPhase = isWin ? "won" : "lost";

      phaseRef.current = nextPhase;
      setPhase(nextPhase);

      const currentState = getGameState();
      const finalEscapeScore = currentState.score + scoreRef.current;

      saveGameState({
        score: finalEscapeScore,
        escapeCompleted: isWin,
        bossDefeated: false,
        difficultyMode,
      });

      setStatusText(
        isWin
          ? "หนีพ้นถ้ำสมุทรแล้ว! เตรียมเข้าสู่ด่านคำกลอน"
          : "พลังหมดก่อนหนีออกจากถ้ำ..."
      );

      redirectTimerRef.current = setTimeout(() => {
        router.push(isWin ? "/game/poem" : "/result");
      }, 1500);
    },
    [difficultyMode, router]
  );

  const startGame = (mode: DifficultyMode) => {
    const selectedModeConfig = GAME_CONFIG.escape.modes[mode];

    setDifficultyMode(mode);
    setPhase("playing");
    phaseRef.current = "playing";

    setPlayerLane(1);
    playerLaneRef.current = 1;

    setHp(selectedModeConfig.maxHP);
    hpRef.current = selectedModeConfig.maxHP;

    setDistance(0);
    setScore(0);
    scoreRef.current = 0;

    setCombo(0);
    comboRef.current = 0;

    setObstacles([]);
    setActiveQuestion(null);

    hitEntityIdsRef.current = new Set();
    dodgedEntityIdsRef.current = new Set();
    obstacleIdRef.current = 1;

    saveGameState({
      difficultyMode: mode,
      escapeCompleted: false,
    });

    setStatusText(`เริ่มโหมด${selectedModeConfig.label}! หลบให้รอดและเก็บไอเทมให้ทัน`);
  };

  const moveLane = (direction: -1 | 1) => {
    if (phaseRef.current !== "playing") return;

    setPlayerLane((currentLane) => {
      const nextLane = Math.max(0, Math.min(2, currentLane + direction));
      playerLaneRef.current = nextLane;
      return nextLane;
    });
  };

  const addScoreInstant = (points: number) => {
    setScore((currentScore) => {
      const nextScore = currentScore + points;
      scoreRef.current = nextScore;
      return nextScore;
    });
  };

  const resetCombo = () => {
    comboRef.current = 0;
    setCombo(0);
  };

  const addDodgeCombo = (amount: number) => {
    const oldCombo = comboRef.current;
    const nextCombo = oldCombo + amount;

    comboRef.current = nextCombo;
    setCombo(nextCombo);

    const smallBonus = amount * GAME_CONFIG.escape.comboSmallBonus;

    const oldBigBonusCount = Math.floor(oldCombo / GAME_CONFIG.escape.comboBonusEvery);
    const nextBigBonusCount = Math.floor(nextCombo / GAME_CONFIG.escape.comboBonusEvery);

    const bigBonus =
      (nextBigBonusCount - oldBigBonusCount) * GAME_CONFIG.escape.comboBigBonus;

    const totalBonus = smallBonus + bigBonus;

    addScoreInstant(totalBonus);

    if (bigBonus > 0) {
      setStatusText(`คอมโบ ${nextCombo}! หลบต่อเนื่อง ได้โบนัส +${totalBonus}`);
    } else {
      setStatusText(`หลบสำเร็จ! คอมโบ ${nextCombo} +${totalBonus}`);
    }
  };

  const answerEscapeQuestion = (choiceIndex: number) => {
    if (!activeQuestion) return;

    const isCorrect = choiceIndex === activeQuestion.correctAnswer;
    const currentState = getGameState();

    if (isCorrect) {
      saveGameState({
        correctAnswers: currentState.correctAnswers + 1,
      });

      addScoreInstant(GAME_CONFIG.escape.questionReward);

      setDistance((currentDistance) => {
        const nextDistance = Math.min(
          GAME_CONFIG.escape.maxDistance,
          currentDistance + GAME_CONFIG.escape.questionDistanceBonus
        );

        if (nextDistance >= GAME_CONFIG.escape.maxDistance) {
          finishGame(true);
        }

        return nextDistance;
      });

      setStatusText(
        `ตอบถูก! ได้คะแนน +${GAME_CONFIG.escape.questionReward} และหนีได้เร็วขึ้น`
      );

      setActiveQuestion(null);

      setTimeout(() => {
        if (phaseRef.current !== "won" && phaseRef.current !== "lost") {
          phaseRef.current = "playing";
          setPhase("playing");
        }
      }, 650);

      return;
    }

    saveGameState({
      wrongAnswers: currentState.wrongAnswers + 1,
    });

    const nextHp = Math.max(0, hpRef.current - Math.ceil(modeConfig.hitDamage / 2));

    hpRef.current = nextHp;
    setHp(nextHp);
    resetCombo();

    setStatusText("ตอบผิด! เสียจังหวะหนีและพลังชีวิตลดลง");
    setActiveQuestion(null);
    setIsHit(true);

    setTimeout(() => setIsHit(false), 220);

    if (nextHp <= 0) {
      finishGame(false);
      return;
    }

    setTimeout(() => {
      if (phaseRef.current !== "won" && phaseRef.current !== "lost") {
        phaseRef.current = "playing";
        setPhase("playing");
      }
    }, 650);
  };

  useEffect(() => {
    playerLaneRef.current = playerLane;
  }, [playerLane]);

  useEffect(() => {
    hpRef.current = hp;
  }, [hp]);

  useEffect(() => {
    scoreRef.current = score;
  }, [score]);

  useEffect(() => {
    comboRef.current = combo;
  }, [combo]);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    if (phase !== "playing") return;

    gameLoopRef.current = setInterval(() => {
      setScore((currentScore) => {
        const nextScore = currentScore + modeConfig.scorePerTick;
        scoreRef.current = nextScore;
        return nextScore;
      });

      setDistance((currentDistance) => {
        const nextDistance = Math.min(
          GAME_CONFIG.escape.maxDistance,
          currentDistance + modeConfig.distancePerTick
        );

        if (nextDistance >= GAME_CONFIG.escape.maxDistance) {
          finishGame(true);
        }

        return nextDistance;
      });

      setObstacles((currentObstacles) => {
        return currentObstacles
          .map((entity) => ({
            ...entity,
            x: entity.x - entity.speed,
          }))
          .filter((entity) => entity.x > -20);
      });
    }, modeConfig.tickMs);

    spawnLoopRef.current = setInterval(() => {
      setObstacles((currentObstacles) => {
        const nextEntity = createEntity(obstacleIdRef.current++, modeConfig);
        return [...currentObstacles, nextEntity];
      });
    }, modeConfig.spawnMs);

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      if (spawnLoopRef.current) clearInterval(spawnLoopRef.current);
    };
  }, [phase, modeConfig, finishGame]);

  useEffect(() => {
    if (phase !== "playing") return;

    const collidedEntity = obstacles.find((entity) => {
      const isSameLane = entity.lane === playerLaneRef.current;
      const isInHitZone = entity.x <= 34 && entity.x >= 18;
      const alreadyHit = hitEntityIdsRef.current.has(entity.id);

      return isSameLane && isInHitZone && !alreadyHit;
    });

    if (!collidedEntity) return;

    hitEntityIdsRef.current.add(collidedEntity.id);

    setObstacles((currentObstacles) =>
      currentObstacles.filter((entity) => entity.id !== collidedEntity.id)
    );

    const meta = ENTITY_META[collidedEntity.type];

    if (collidedEntity.type === "heal") {
      const nextHp = Math.min(modeConfig.maxHP, hpRef.current + modeConfig.healAmount);

      hpRef.current = nextHp;
      setHp(nextHp);
      addScoreInstant(20);

      setStatusText(`เก็บ${meta.label}! ฟื้นพลัง +${modeConfig.healAmount}`);
      return;
    }

    if (collidedEntity.type === "quiz") {
      setActiveQuestion(getRandomQuestion());
      phaseRef.current = "quiz";
      setPhase("quiz");
      setStatusText("เจอคำถามวรรณคดี! ตอบให้ถูกเพื่อเร่งความเร็ว");
      return;
    }

    if (isDamageEntity(collidedEntity.type)) {
      const nextHp = Math.max(0, hpRef.current - modeConfig.hitDamage);

      hpRef.current = nextHp;
      setHp(nextHp);
      resetCombo();

      setIsHit(true);
      setStatusText(`ชน${meta.label}! พลังชีวิต -${modeConfig.hitDamage}`);

      setTimeout(() => {
        setIsHit(false);
      }, 220);

      if (nextHp <= 0) {
        finishGame(false);
      }
    }
  }, [obstacles, phase, modeConfig, finishGame]);

  useEffect(() => {
    if (phase !== "playing") return;

    const dodgedEntities = obstacles.filter((entity) => {
      const alreadyDodged = dodgedEntityIdsRef.current.has(entity.id);
      const hasPassedPlayer = entity.x < 18 && entity.x > 0;
      const isNotSameLane = entity.lane !== playerLaneRef.current;

      return (
        isDamageEntity(entity.type) &&
        !alreadyDodged &&
        hasPassedPlayer &&
        isNotSameLane
      );
    });

    if (dodgedEntities.length === 0) return;

    dodgedEntities.forEach((entity) => {
      dodgedEntityIdsRef.current.add(entity.id);
    });

    addDodgeCombo(dodgedEntities.length);
  }, [obstacles, phase]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowUp") moveLane(-1);
      if (event.key === "ArrowDown") moveLane(1);
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);

      if (redirectTimerRef.current) {
        clearTimeout(redirectTimerRef.current);
      }
    };
  }, []);

  if (phase === "setup") {
    return (
      <Screen className="justify-center bg-gradient-to-b from-slate-950 via-thai-dark to-black p-5">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-thai-gold/50 bg-black/55 p-5 shadow-2xl backdrop-blur"
        >
          <h1 className="mb-2 text-center text-3xl font-bold text-thai-gold">
            เลือกโหมดหนีถ้ำสมุทร
          </h1>

          <p className="mb-6 text-center text-sm leading-6 text-thai-cream/75">
            โหมดความยากจะเปลี่ยนเลือด ความเร็วสิ่งกีดขวาง ความถี่ของไอเทม
            และคะแนนที่ได้รับ
          </p>

          <div className="space-y-3">
            {(Object.keys(GAME_CONFIG.escape.modes) as DifficultyMode[]).map(
              (mode) => {
                const config = GAME_CONFIG.escape.modes[mode];

                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => startGame(mode)}
                    className="w-full rounded-xl border border-thai-gold/30 bg-thai-dark/80 p-4 text-left active:scale-[0.98]"
                  >
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-xl font-bold text-thai-gold">
                        โหมด{config.label}
                      </span>
                      <span className="rounded-full bg-black/50 px-3 py-1 text-xs text-thai-cream/70">
                        HP {config.maxHP}
                      </span>
                    </div>

                    <p className="text-sm leading-6 text-thai-cream/75">
                      {config.description}
                    </p>
                  </button>
                );
              }
            )}
          </div>

          <div className="mt-5">
            <Button onClick={() => router.push("/story")} variant="outline">
              กลับหน้าเนื้อเรื่อง
            </Button>
          </div>
        </motion.div>
      </Screen>
    );
  }

  return (
    <Screen className="bg-gradient-to-r from-blue-950 via-thai-ocean to-slate-950">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          animate={{ x: [0, -24, 0], opacity: [0.18, 0.35, 0.18] }}
          transition={{ repeat: Infinity, duration: 4 }}
          className="absolute left-[-80px] top-16 h-56 w-56 rounded-full bg-red-700/30 blur-3xl"
        />

        <motion.div
          animate={{ x: [0, 22, 0], opacity: [0.15, 0.3, 0.15] }}
          transition={{ repeat: Infinity, duration: 5 }}
          className="absolute bottom-[-70px] right-[-70px] h-60 w-60 rounded-full bg-blue-300/25 blur-3xl"
        />
      </div>

      <div className="relative z-20 space-y-3 p-4">
        <div className="flex items-center justify-between text-sm font-bold text-thai-cream">
          <span>คะแนน: {score}</span>
          <span>โหมด: {modeConfig.label}</span>
          <span>ระยะทาง: {Math.floor(distance)}%</span>
        </div>

        <Bar
          value={hp}
          max={modeConfig.maxHP}
          colorClass="bg-green-500"
          label="พลังชีวิตนางเงือก"
        />

        <div className="h-3 overflow-hidden rounded-full border border-thai-gold/30 bg-black/50">
          <motion.div
            className="h-full bg-thai-gold"
            animate={{ width: `${distance}%` }}
            transition={{ duration: 0.25 }}
          />
        </div>

        <div className="flex items-center justify-between rounded-xl border border-thai-gold/20 bg-black/35 px-3 py-2 text-xs text-thai-cream/80">
          <span>คอมโบหลบ: {combo}</span>
          <span>ครบทุก {GAME_CONFIG.escape.comboBonusEvery} คอมโบ ได้โบนัสใหญ่</span>
        </div>
      </div>

      <motion.div
        animate={isHit ? { x: [-8, 8, -6, 6, 0] } : { x: 0 }}
        transition={{ duration: 0.22 }}
        className="relative z-10 mx-4 flex-1 overflow-hidden rounded-2xl border-2 border-thai-gold/30 bg-black/20"
      >
        <div className="absolute inset-0">
          {[0, 1, 2].map((lane) => (
            <div
              key={lane}
              className="absolute left-0 right-0 border-t border-white/10"
              style={{ top: LANE_TOP[lane] }}
            />
          ))}
        </div>

        <motion.div
          className="absolute left-0 top-0 z-10 flex h-full w-16 items-center justify-center border-r-4 border-red-800 bg-black/60"
          animate={{ opacity: [0.65, 1, 0.65] }}
          transition={{ repeat: Infinity, duration: 0.8 }}
        >
          <span className="-rotate-90 whitespace-nowrap text-xs font-bold text-red-300">
            ผีเสื้อสมุทรไล่ล่า
          </span>
        </motion.div>

        <motion.div
          className="absolute left-[24%] z-30 flex h-14 w-14 -translate-y-1/2 items-center justify-center rounded-full border-2 border-teal-200 bg-thai-jade text-2xl shadow-[0_0_24px_rgba(20,184,166,0.8)]"
          animate={{
            top: LANE_TOP[playerLane],
            scale: isHit ? [1, 1.15, 0.95, 1] : 1,
          }}
          transition={{
            top: { type: "spring", stiffness: 320, damping: 24 },
            scale: { duration: 0.22 },
          }}
        >
          🧜‍♀️
        </motion.div>

        <AnimatePresence>
          {obstacles.map((entity) => {
            const meta = ENTITY_META[entity.type];

            return (
              <motion.div
                key={entity.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  left: `${entity.x}%`,
                  top: LANE_TOP[entity.lane],
                }}
                exit={{ opacity: 0, scale: 0.4 }}
                transition={{ duration: 0.12 }}
                className={`absolute z-20 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border-2 text-2xl shadow-lg ${meta.className}`}
                aria-label={meta.label}
              >
                {meta.icon}
              </motion.div>
            );
          })}
        </AnimatePresence>

        <div className="pointer-events-none absolute bottom-3 left-3 right-3 z-40 rounded-xl border border-thai-gold/25 bg-black/55 px-4 py-3 text-center text-sm font-medium text-thai-cream backdrop-blur">
          {statusText}
        </div>
      </motion.div>

      <div className="relative z-20 grid grid-cols-2 gap-3 bg-thai-dark/95 p-4">
        <Button
          onClick={() => moveLane(-1)}
          variant="blue"
          disabled={playerLane === 0 || phase !== "playing"}
        >
          ▲ ว่ายขึ้น
        </Button>

        <Button
          onClick={() => moveLane(1)}
          variant="blue"
          disabled={playerLane === 2 || phase !== "playing"}
        >
          ▼ ว่ายลง
        </Button>
      </div>

      <AnimatePresence>
        {phase === "quiz" && activeQuestion && (
          <motion.div
            initial={{ opacity: 0, y: 80 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 80 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-5"
          >
            <div className="w-full rounded-2xl border-2 border-thai-gold bg-thai-dark p-5 shadow-2xl">
              <h2 className="mb-2 text-center text-2xl font-bold text-thai-gold">
                คำถามระหว่างหนี
              </h2>

              <p className="mb-5 text-center text-lg leading-7 text-thai-cream">
                {activeQuestion.question}
              </p>

              <div className="space-y-3">
                {activeQuestion.choices.map((choice, index) => (
                  <Button
                    key={choice}
                    onClick={() => answerEscapeQuestion(index)}
                    variant="outline"
                  >
                    {choice}
                  </Button>
                ))}
              </div>

              <p className="mt-4 text-center text-xs text-thai-cream/60">
                ตอบถูก = ได้คะแนนและเพิ่มระยะหนี / ตอบผิด = เสียพลังชีวิต
              </p>
            </div>
          </motion.div>
        )}

        {(phase === "won" || phase === "lost") && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 p-6 text-center"
          >
            <motion.div
              initial={{ y: 24, scale: 0.95 }}
              animate={{ y: 0, scale: 1 }}
              className="w-full rounded-2xl border-2 border-thai-gold bg-thai-dark p-6 shadow-2xl"
            >
              <h2 className="mb-3 text-3xl font-bold text-thai-gold">
                {phase === "won" ? "หนีพ้นถ้ำ!" : "หนีไม่สำเร็จ"}
              </h2>

              <p className="mb-4 leading-7 text-thai-cream">
                {phase === "won"
                  ? "ครอบครัวเงือกพาพระอภัยมณีออกจากถ้ำได้สำเร็จ"
                  : "พลังชีวิตหมดก่อนหนีออกจากถ้ำสมุทร"}
              </p>

              <p className="text-sm text-thai-cream/70">
                กำลังไปหน้าถัดไป...
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Screen>
  );
}
