"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Button from "@/components/Button";
import Screen from "@/components/Screen";
import SceneCard from "@/components/SceneCard";
import { poemFragments } from "@/data/questions";
import { GAME_CONFIG } from "@/lib/gameConstants";
import { getGameState, saveGameState } from "@/lib/gameStorage";
import type { PoemFragment } from "@/types/game";

interface WordToken {
  id: string;
  word: string;
}

function shuffleArray<T>(items: T[]): T[] {
  const copiedItems = [...items];

  for (let i = copiedItems.length - 1; i > 0; i--) {
    const randomIndex = Math.floor(Math.random() * (i + 1));
    const temp = copiedItems[i];
    copiedItems[i] = copiedItems[randomIndex];
    copiedItems[randomIndex] = temp;
  }

  return copiedItems;
}

function createWordTokens(words: string[]): WordToken[] {
  return words.map((word, index) => ({
    id: `${word}-${index}-${Math.random().toString(36).slice(2)}`,
    word,
  }));
}

function getRandomPoem(): PoemFragment {
  return poemFragments[Math.floor(Math.random() * poemFragments.length)];
}

export default function PoemGamePage() {
  const router = useRouter();

  const initialPoem = poemFragments[0];

  const [poem, setPoem] = useState<PoemFragment>(initialPoem);
  const [availableWords, setAvailableWords] = useState<WordToken[]>(
    shuffleArray(createWordTokens(initialPoem.scrambled))
  );
  const [selectedWords, setSelectedWords] = useState<WordToken[]>([]);
  const [result, setResult] = useState<"idle" | "correct" | "wrong">("idle");
  const [attempts, setAttempts] = useState(0);
  const [earnedBonus, setEarnedBonus] = useState(false);

  const selectedSentence = selectedWords.map((token) => token.word).join(" ");
  const correctSentence = poem.correct.join(" ");
  const isComplete = availableWords.length === 0;

  const selectWord = (token: WordToken) => {
    if (result === "correct") return;

    setSelectedWords((currentSelectedWords) => [
      ...currentSelectedWords,
      token,
    ]);

    setAvailableWords((currentAvailableWords) =>
      currentAvailableWords.filter((item) => item.id !== token.id)
    );

    setResult("idle");
  };

  const unselectWord = (token: WordToken) => {
    if (result === "correct") return;

    setAvailableWords((currentAvailableWords) => [
      ...currentAvailableWords,
      token,
    ]);

    setSelectedWords((currentSelectedWords) =>
      currentSelectedWords.filter((item) => item.id !== token.id)
    );

    setResult("idle");
  };

  const resetCurrentPoem = () => {
    if (result === "correct") return;

    setAvailableWords(shuffleArray(createWordTokens(poem.scrambled)));
    setSelectedWords([]);
    setResult("idle");
  };

  const changePoem = () => {
    if (result === "correct") return;

    const nextPoem = getRandomPoem();

    setPoem(nextPoem);
    setAvailableWords(shuffleArray(createWordTokens(nextPoem.scrambled)));
    setSelectedWords([]);
    setResult("idle");
    setAttempts(0);
  };

  const checkAnswer = () => {
    if (!isComplete || result === "correct") return;

    const playerAnswer = selectedWords.map((token) => token.word).join("|");
    const correctAnswer = poem.correct.join("|");
    const isCorrect = playerAnswer === correctAnswer;

    setAttempts((currentAttempts) => currentAttempts + 1);

    if (!isCorrect) {
      setResult("wrong");
      return;
    }

    const currentState = getGameState();

    const attemptPenalty = Math.min(attempts * 20, 60);
    const finalScoreBonus = Math.max(
      40,
      GAME_CONFIG.poem.correctBonus - attemptPenalty
    );

    saveGameState({
      score: currentState.score + finalScoreBonus,
      poemBonus: GAME_CONFIG.poem.hpBonus,
    });

    setEarnedBonus(true);
    setResult("correct");
  };

  return (
    <Screen className="justify-center bg-gradient-to-b from-slate-950 via-thai-dark to-black p-5">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          animate={{ opacity: [0.18, 0.34, 0.18], y: [0, -14, 0] }}
          transition={{ repeat: Infinity, duration: 5 }}
          className="absolute left-[-80px] top-20 h-56 w-56 rounded-full bg-thai-gold/20 blur-3xl"
        />

        <motion.div
          animate={{ opacity: [0.14, 0.28, 0.14], y: [0, 18, 0] }}
          transition={{ repeat: Infinity, duration: 6 }}
          className="absolute bottom-[-80px] right-[-70px] h-60 w-60 rounded-full bg-blue-400/20 blur-3xl"
        />
      </div>

      <SceneCard title="ด่านที่ 2: เรียงคำกลอน" className="relative z-10">
        <div className="mb-5 rounded-xl border border-thai-gold/20 bg-black/35 p-4 text-center">
          <p className="mb-1 text-sm text-thai-cream/60">โจทย์</p>

          <h3 className="text-xl font-bold text-thai-gold">{poem.title}</h3>

          <p className="mt-2 text-xs leading-5 text-thai-cream/60">
            แตะคำด้านล่างเพื่อเรียงให้เป็นประโยคที่ถูกต้อง
          </p>
        </div>

        <div className="mb-5 min-h-[88px] rounded-xl border-2 border-thai-gold/40 bg-black/45 p-3">
          {selectedWords.length === 0 ? (
            <div className="flex h-[58px] items-center justify-center text-center text-sm text-thai-cream/45">
              คำที่เลือกจะแสดงตรงนี้
            </div>
          ) : (
            <div className="flex flex-wrap justify-center gap-2">
              {selectedWords.map((token, index) => (
                <motion.button
                  key={token.id}
                  type="button"
                  layout
                  whileTap={{ scale: 0.94 }}
                  onClick={() => unselectWord(token)}
                  className="rounded-lg bg-thai-ocean px-3 py-2 text-sm font-bold text-white shadow"
                >
                  {index + 1}. {token.word}
                </motion.button>
              ))}
            </div>
          )}
        </div>

        <div className="mb-5 flex min-h-[92px] flex-wrap justify-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3">
          <AnimatePresence>
            {availableWords.map((token) => (
              <motion.button
                key={token.id}
                type="button"
                layout
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.6 }}
                whileTap={{ scale: 0.92 }}
                onClick={() => selectWord(token)}
                className="rounded-lg bg-thai-gold px-4 py-2 text-sm font-bold text-thai-dark shadow-lg"
              >
                {token.word}
              </motion.button>
            ))}
          </AnimatePresence>

          {availableWords.length === 0 && (
            <div className="flex items-center justify-center text-sm text-thai-cream/50">
              เลือกครบแล้ว กดตรวจคำตอบได้เลย
            </div>
          )}
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3">
          <Button
            onClick={resetCurrentPoem}
            variant="outline"
            disabled={result === "correct"}
          >
            เริ่มใหม่
          </Button>

          <Button
            onClick={changePoem}
            variant="outline"
            disabled={result === "correct"}
          >
            เปลี่ยนโจทย์
          </Button>
        </div>

        <Button
          onClick={checkAnswer}
          disabled={!isComplete || result === "correct"}
        >
          ตรวจคำตอบ
        </Button>

        <AnimatePresence>
          {result === "wrong" && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-5 rounded-xl border border-red-400/40 bg-red-950/40 p-4 text-center"
            >
              <p className="font-bold text-red-300">ยังไม่ถูก ลองจัดใหม่อีกที</p>
              <p className="mt-1 text-xs text-thai-cream/60">
                แตะคำด้านบนเพื่อเอาคำกลับ แล้วเรียงใหม่ได้
              </p>
            </motion.div>
          )}

          {result === "correct" && (
            <motion.div
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0 }}
              className="mt-5 rounded-xl border border-green-400/40 bg-emerald-950/35 p-4"
            >
              <h3 className="mb-2 text-center text-xl font-bold text-green-300">
                ถูกต้อง!
              </h3>

              <div className="space-y-3 text-sm leading-6 text-thai-cream/80">
                <p>
                  <span className="font-bold text-thai-gold">คำตอบ:</span>{" "}
                  {correctSentence}
                </p>

                <p>
                  <span className="font-bold text-thai-gold">ความรู้:</span>{" "}
                  {poem.explanation}
                </p>

                {earnedBonus && (
                  <p className="rounded-lg bg-black/35 p-3 text-center text-green-300">
                    ได้รับคะแนน + โบนัสพลังชีวิต +{GAME_CONFIG.poem.hpBonus} สำหรับด่านบอส
                  </p>
                )}
              </div>

              <div className="mt-5">
                <Button onClick={() => router.push("/game/boss")}>
                  ไปด่านสุดท้าย: สู้ผีเสื้อสมุทร
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {result !== "correct" && (
          <div className="mt-5 rounded-xl border border-thai-gold/15 bg-black/25 p-3 text-center text-xs leading-5 text-thai-cream/55">
            คำตอบที่เรียงตอนนี้:{" "}
            <span className="text-thai-cream/80">
              {selectedSentence || "ยังไม่ได้เลือกคำ"}
            </span>
          </div>
        )}
      </SceneCard>
    </Screen>
  );
}
