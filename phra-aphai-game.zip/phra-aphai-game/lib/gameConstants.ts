import type { GameState } from "@/types/game";

export const STORAGE_KEY = "phraAphaiState";

export const DEFAULT_GAME_STATE: GameState = {
  score: 0,
  rank: "",
  escapeCompleted: false,
  poemBonus: 0,
  bossDefeated: false,
  correctAnswers: 0,
  wrongAnswers: 0,
  totalPlayTime: 0,
  difficultyMode: "normal",
};

export const GAME_CONFIG = {
  escape: {
    maxDistance: 100,
    comboBonusEvery: 5,
    comboSmallBonus: 10,
    comboBigBonus: 50,
    questionReward: 80,
    questionDistanceBonus: 6,
    modes: {
      easy: {
        label: "ง่าย",
        description: "เหมาะกับงานโรงเรียน เล่นง่าย ไม่หัวร้อน",
        maxHP: 120,
        distancePerTick: 3.6,
        scorePerTick: 5,
        tickMs: 360,
        spawnMs: 1050,
        baseSpeed: 6,
        hitDamage: 14,
        healAmount: 25,
        healChance: 0.18,
        quizChance: 0.14,
      },
      normal: {
        label: "ปกติ",
        description: "สมดุล เล่นสนุก มีความกดดันพอดี",
        maxHP: 100,
        distancePerTick: 3,
        scorePerTick: 6,
        tickMs: 330,
        spawnMs: 850,
        baseSpeed: 8,
        hitDamage: 20,
        healAmount: 22,
        healChance: 0.12,
        quizChance: 0.12,
      },
      hard: {
        label: "ยาก",
        description: "สำหรับคนอยากท้าทาย สิ่งกีดขวางถี่และแรงกว่า",
        maxHP: 85,
        distancePerTick: 2.7,
        scorePerTick: 8,
        tickMs: 300,
        spawnMs: 650,
        baseSpeed: 10,
        hitDamage: 26,
        healAmount: 18,
        healChance: 0.08,
        quizChance: 0.1,
      },
    },
  },
  poem: {
    correctBonus: 100,
    hpBonus: 50,
  },
  boss: {
    playerBaseHP: 100,
    bossMaxRage: 200,
    correctDamage: 50,
    wrongDamage: 30,
    victoryBonus: 500,
  },
} as const;
