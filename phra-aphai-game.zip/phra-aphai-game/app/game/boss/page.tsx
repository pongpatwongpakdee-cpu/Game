"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Button from "@/components/Button";
import Bar from "@/components/Bar";
import Screen from "@/components/Screen";
import { questions } from "@/data/questions";
import { GAME_CONFIG } from "@/lib/gameConstants";
import { getGameState, saveGameState } from "@/lib/gameStorage";
import type { DifficultyMode, Question } from "@/types/game";

type BossPhase = 1 | 2 | 3;

type BattleStatus =
  | "intro"
  | "selecting"
  | "quiz"
  | "feedback"
  | "won"
  | "lost";

interface BattleLog {
  id: string;
  text: string;
  tone: "normal" | "good" | "bad" | "warning";
}

interface FeedbackState {
  title: string;
  message: string;
  fact?: string;
  tone: "correct" | "wrong" | "neutral";
}

const BOSS_MAX_RAGE = 300;

const PHASE_CONFIG: Record<
  BossPhase,
  {
    title: string;
    subtitle: string;
    quote: string;
    correctDamage: number;
    attackDamage: number;
    attackName: string;
    auraClass: string;
    bodyClass: string;
    ringClass: string;
    bgClass: string;
  }
> = {
  1: {
    title: "ระยะที่ 1: เสียงคลื่นร่ำไห้",
    subtitle: "ผีเสื้อสมุทรยังควบคุมความโกรธได้บางส่วน",
    quote: "เจ้าจะหนีข้าไปมิได้...",
    correctDamage: 45,
    attackDamage: 18,
    attackName: "คลื่นสมุทรกระแทก",
    auraClass: "bg-red-700/25",
    bodyClass: "bg-red-900 border-red-400",
    ringClass: "border-red-400/50",
    bgClass: "from-blue-950 via-slate-950 to-black",
  },
  2: {
    title: "ระยะที่ 2: ถ้ำสมุทรแตกตื่น",
    subtitle: "ความโกรธเริ่มกลืนกินทั้งทะเล",
    quote: "แม้แต่ทะเลก็ต้องฟังเสียงข้า!",
    correctDamage: 38,
    attackDamage: 27,
    attackName: "กรงเล็บยักษ์ใต้ทะเล",
    auraClass: "bg-orange-700/30",
    bodyClass: "bg-orange-950 border-orange-300",
    ringClass: "border-orange-300/60",
    bgClass: "from-slate-950 via-blue-950 to-orange-950",
  },
  3: {
    title: "ระยะสุดท้าย: สมุทรพิโรธ",
    subtitle: "บอสเข้าสู่สภาวะคลุ้มคลั่ง โจมตีแรงขึ้น",
    quote: "หากไม่ได้ครอบครอง ก็จงจมไปพร้อมทะเล!",
    correctDamage: 32,
    attackDamage: 36,
    attackName: "เสียงคร่ำครวญแห่งถ้ำสมุทร",
    auraClass: "bg-red-600/40",
    bodyClass: "bg-black border-red-300",
    ringClass: "border-red-200/80",
    bgClass: "from-black via-red-950 to-slate-950",
  },
};

function getRandomQuestion(): Question {
  return questions[Math.floor(Math.random() * questions.length)];
}

function getBossPhase(rage: number): BossPhase {
  const percentage = rage / BOSS_MAX_RAGE;

  if (percentage > 0.66) return 1;
  if (percentage > 0.33) return 2;
  return 3;
}

function createLog(text: string, tone: BattleLog["tone"] = "normal"): BattleLog {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    text,
    tone,
  };
}

function getLogColor(tone: BattleLog["tone"]) {
  if (tone === "good") return "text-green-300";
  if (tone === "bad") return "text-red-300";
  if (tone === "warning") return "text-thai-gold";
  return "text-thai-cream/80";
}

function getMaxPlayerHP(difficultyMode: DifficultyMode, poemBonus: number) {
  if (difficultyMode === "easy") {
    return GAME_CONFIG.boss.playerBaseHP + poemBonus + 20;
  }

  if (difficultyMode === "hard") {
    return GAME_CONFIG.boss.playerBaseHP + poemBonus - 10;
  }

  return GAME_CONFIG.boss.playerBaseHP + poemBonus;
}

export default function BossFightPage() {
  const router = useRouter();

  const [difficultyMode, setDifficultyMode] = useState<DifficultyMode>("normal");
  const [poemBonus, setPoemBonus] = useState(0);

  const maxPlayerHP = useMemo(
    () => getMaxPlayerHP(difficultyMode, poemBonus),
    [difficultyMode, poemBonus]
  );

  const [status, setStatus] = useState<BattleStatus>("intro");
  const [playerHP, setPlayerHP] = useState(maxPlayerHP);
  const [bossRage, setBossRage] = useState(BOSS_MAX_RAGE);
  const [battleScore, setBattleScore] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [feedback, setFeedback] = useState<FeedbackState | null>(null);
  const [guarding, setGuarding] = useState(false);
  const [focusCooldown, setFocusCooldown] = useState(0);
  const [screenShake, setScreenShake] = useState(false);
  const [logs, setLogs] = useState<BattleLog[]>([
    createLog("พระอภัยมณียืนประจันหน้าผีเสื้อสมุทรกลางคลื่นดำ", "warning"),
  ]);

  useEffect(() => {
    const storedState = getGameState();
    const nextMaxHP = getMaxPlayerHP(storedState.difficultyMode, storedState.poemBonus);

    setDifficultyMode(storedState.difficultyMode);
    setPoemBonus(storedState.poemBonus);
    setPlayerHP(nextMaxHP);
  }, []);

  const bossPhase = getBossPhase(bossRage);
  const phaseConfig = PHASE_CONFIG[bossPhase];

  const pushLog = (text: string, tone: BattleLog["tone"] = "normal") => {
    setLogs((currentLogs) => [createLog(text, tone), ...currentLogs].slice(0, 5));
  };

  const triggerShake = () => {
    setScreenShake(true);

    setTimeout(() => {
      setScreenShake(false);
    }, 250);
  };

  const finishGame = (isWin: boolean, nextPlayerHP: number, nextScore: number) => {
    const currentState = getGameState();

    const finalScore =
      currentState.score +
      nextScore +
      (isWin ? GAME_CONFIG.boss.victoryBonus : 0) +
      Math.max(0, nextPlayerHP * 2);

    saveGameState({
      score: finalScore,
      bossDefeated: isWin,
    });

    setStatus(isWin ? "won" : "lost");
  };

  const calculateBossDamage = (phase: BossPhase, isGuarding: boolean) => {
    const baseDamage = PHASE_CONFIG[phase].attackDamage;

    if (isGuarding) {
      return Math.ceil(baseDamage * 0.35);
    }

    return baseDamage;
  };

  const bossAttack = (options?: {
    isGuarding?: boolean;
    fromHP?: number;
    reason?: string;
  }) => {
    const isGuarding = options?.isGuarding ?? guarding;
    const startingHP = options?.fromHP ?? playerHP;
    const damage = calculateBossDamage(bossPhase, isGuarding);
    const nextPlayerHP = Math.max(0, startingHP - damage);

    setPlayerHP(nextPlayerHP);
    setGuarding(false);
    triggerShake();

    if (isGuarding) {
      pushLog(
        `ตั้งรับสำเร็จ! ${phaseConfig.attackName} ถูกลดความเสียหาย เหลือ -${damage} HP`,
        "warning"
      );
    } else {
      pushLog(`โดน ${phaseConfig.attackName}! เสีย HP -${damage}`, "bad");
    }

    if (nextPlayerHP <= 0) {
      finishGame(false, nextPlayerHP, battleScore);
    }

    return nextPlayerHP;
  };

  const startBattle = () => {
    setStatus("selecting");
    pushLog("การต่อสู้เริ่มขึ้น เสียงปี่คือความหวังสุดท้าย", "warning");
  };

  const openQuestion = () => {
    setCurrentQuestion(getRandomQuestion());
    setStatus("quiz");
  };

  const handleAnswer = (choiceIndex: number) => {
    if (!currentQuestion) return;

    const isCorrect = choiceIndex === currentQuestion.correctAnswer;
    const currentState = getGameState();

    if (isCorrect) {
      const damage = phaseConfig.correctDamage;
      const nextBossRage = Math.max(0, bossRage - damage);
      const nextScore = battleScore + damage * 4 + 40;
      const oldPhase = bossPhase;
      const nextPhase = getBossPhase(nextBossRage);

      setBossRage(nextBossRage);
      setBattleScore(nextScore);

      saveGameState({
        correctAnswers: currentState.correctAnswers + 1,
      });

      pushLog(
        `ตอบถูก! เสียงปี่วิเศษทะลวงความโกรธของผีเสื้อสมุทร -${damage} Rage`,
        "good"
      );

      if (nextPhase !== oldPhase && nextBossRage > 0) {
        pushLog(PHASE_CONFIG[nextPhase].title, "warning");
      }

      setFeedback({
        title: "โจมตีสำเร็จ!",
        message: `เสียงปี่วิเศษลดความโกรธของบอส ${damage} หน่วย`,
        fact: currentQuestion.fact,
        tone: "correct",
      });

      setCurrentQuestion(null);

      if (nextBossRage <= 0) {
        finishGame(true, playerHP, nextScore);
        return;
      }

      setStatus("feedback");
      return;
    }

    saveGameState({
      wrongAnswers: currentState.wrongAnswers + 1,
    });

    const damage = calculateBossDamage(bossPhase, false);
    const nextPlayerHP = Math.max(0, playerHP - damage);
    const nextScore = Math.max(0, battleScore + 10);

    setPlayerHP(nextPlayerHP);
    setBattleScore(nextScore);
    setGuarding(false);
    triggerShake();

    pushLog(
      `ตอบผิด! พลังปี่สะดุด บอสสวนด้วย ${phaseConfig.attackName} -${damage} HP`,
      "bad"
    );

    setFeedback({
      title: "พลาดจังหวะ!",
      message: `ตอบผิดและโดนบอสสวนกลับ เสียพลังชีวิต ${damage} หน่วย`,
      fact: currentQuestion.fact,
      tone: "wrong",
    });

    setCurrentQuestion(null);

    if (nextPlayerHP <= 0) {
      finishGame(false, nextPlayerHP, nextScore);
      return;
    }

    setStatus("feedback");
  };

  const continueBattle = () => {
    setFeedback(null);

    setFocusCooldown((currentCooldown) => Math.max(0, currentCooldown - 1));
    setStatus("selecting");
  };

  const guardAction = () => {
    setGuarding(true);
    pushLog("พระอภัยมณีตั้งรับ อ่านจังหวะคลื่นก่อนบอสโจมตี", "warning");

    const nextPlayerHP = bossAttack({ isGuarding: true });

    if (nextPlayerHP > 0) {
      setFocusCooldown((currentCooldown) => Math.max(0, currentCooldown - 1));
      setStatus("selecting");
    }
  };

  const focusAction = () => {
    if (focusCooldown > 0) return;

    const healAmount = bossPhase === 3 ? 16 : 22;
    const nextHP = Math.min(maxPlayerHP, playerHP + healAmount);
    const healedAmount = nextHP - playerHP;

    setPlayerHP(nextHP);
    setFocusCooldown(2);

    pushLog(`รวบรวมลมหายใจ ฟื้น HP +${healedAmount}`, "good");
    pushLog("แต่การหยุดนิ่งเปิดช่องให้บอสโจมตีฟรี", "warning");

    const afterAttackHP = bossAttack({
      isGuarding: false,
      fromHP: nextHP,
    });

    if (afterAttackHP > 0) {
      setStatus("selecting");
    }
  };

  return (
    <Screen className={`bg-gradient-to-b ${phaseConfig.bgClass}`}>
      <motion.div
        animate={screenShake ? { x: [-10, 10, -8, 8, 0] } : { x: 0 }}
        transition={{ duration: 0.25 }}
        className="relative flex min-h-0 flex-1 flex-col"
      >
        <div className="pointer-events-none absolute inset-0">
          <motion.div
            animate={{
              scale: [1, 1.15, 1],
              opacity: [0.25, 0.45, 0.25],
            }}
            transition={{ repeat: Infinity, duration: bossPhase === 3 ? 1.3 : 2.2 }}
            className={`absolute left-1/2 top-[42%] h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl ${phaseConfig.auraClass}`}
          />

          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.65)_75%)]" />
        </div>

        <div className="relative z-20 space-y-3 p-4">
          <div className="flex items-center justify-between text-xs font-bold text-thai-cream/80">
            <span>คะแนนบอส: {battleScore}</span>
            <span>Phase {bossPhase}/3</span>
            <span>โหมด: {difficultyMode}</span>
          </div>

          <Bar
            value={bossRage}
            max={BOSS_MAX_RAGE}
            colorClass={bossPhase === 3 ? "bg-red-500" : "bg-red-700"}
            label="ความโกรธผีเสื้อสมุทร"
          />

          <Bar
            value={playerHP}
            max={maxPlayerHP}
            colorClass="bg-green-500"
            label="พลังชีวิตพระอภัยมณี"
          />
        </div>

        <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-4">
          <motion.div
            animate={{
              scale:
                bossPhase === 3
                  ? [1, 1.08, 1, 1.12, 1]
                  : [1, 1.04, 1],
              rotate:
                bossPhase === 3
                  ? [0, 2, -2, 2, 0]
                  : [0, 1.5, -1.5, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: bossPhase === 3 ? 1.4 : 2.4,
            }}
            className={`relative flex h-40 w-40 items-center justify-center rounded-full border-4 text-center shadow-[0_0_60px_rgba(220,38,38,0.55)] ${phaseConfig.bodyClass}`}
          >
            <motion.div
              animate={{ scale: [1, 1.25, 1], opacity: [0.55, 0.2, 0.55] }}
              transition={{ repeat: Infinity, duration: bossPhase === 3 ? 1 : 1.8 }}
              className={`absolute inset-[-18px] rounded-full border-2 ${phaseConfig.ringClass}`}
            />

            <div className="relative z-10">
              <div className="text-5xl">👹</div>
              <div className="mt-1 text-sm font-bold text-white">
                ผีเสื้อสมุทร
              </div>
            </div>
          </motion.div>

          <div className="mt-6 w-full rounded-2xl border border-thai-gold/25 bg-black/55 p-4 text-center backdrop-blur">
            <h2 className="text-xl font-bold text-thai-gold">
              {phaseConfig.title}
            </h2>

            <p className="mt-1 text-xs leading-5 text-thai-cream/65">
              {phaseConfig.subtitle}
            </p>

            <p className="mt-3 text-sm italic text-red-200">
              “{phaseConfig.quote}”
            </p>
          </div>

          <div className="mt-4 w-full rounded-xl border border-white/10 bg-black/35 p-3">
            <h3 className="mb-2 text-xs font-bold text-thai-gold">
              Battle Log
            </h3>

            <div className="space-y-1">
              {logs.map((log) => (
                <p
                  key={log.id}
                  className={`text-xs leading-5 ${getLogColor(log.tone)}`}
                >
                  • {log.text}
                </p>
              ))}
            </div>
          </div>
        </div>

        <div className="relative z-20 space-y-3 bg-thai-dark/95 p-4">
          {status === "intro" && (
            <>
              <div className="rounded-xl border border-thai-gold/25 bg-black/35 p-4 text-center text-sm leading-6 text-thai-cream/80">
                บอสนี้ไม่ได้ชนะด้วยการกดมั่ว ต้องอ่านจังหวะ เลือกว่าจะโจมตี ตั้งรับ
                หรือฟื้นพลัง ถ้าตอบคำถามผิดจะโดนสวนหนัก
              </div>

              <Button onClick={startBattle} variant="danger">
                เข้าสู่สมรภูมิสุดท้าย
              </Button>
            </>
          )}

          {status === "selecting" && (
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={openQuestion} variant="danger" className="col-span-2">
                เป่าปี่วิเศษโจมตี
              </Button>

              <Button onClick={guardAction} variant="outline">
                ตั้งรับ
              </Button>

              <Button
                onClick={focusAction}
                variant="blue"
                disabled={focusCooldown > 0 || playerHP >= maxPlayerHP}
              >
                {focusCooldown > 0
                  ? `พักอีก ${focusCooldown} เทิร์น`
                  : "รวบรวมลมหายใจ"}
              </Button>
            </div>
          )}
        </div>

        <AnimatePresence>
          {status === "quiz" && currentQuestion && (
            <motion.div
              initial={{ opacity: 0, y: 80 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 80 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-black/92 p-5"
            >
              <div className="w-full rounded-2xl border-2 border-thai-gold bg-thai-dark p-5 shadow-2xl">
                <h2 className="mb-2 text-center text-2xl font-bold text-thai-gold">
                  เป่าปี่วิเศษ
                </h2>

                <p className="mb-5 text-center text-lg leading-7 text-thai-cream">
                  {currentQuestion.question}
                </p>

                <div className="space-y-3">
                  {currentQuestion.choices.map((choice, index) => (
                    <Button
                      key={`${choice}-${index}`}
                      onClick={() => handleAnswer(index)}
                      variant="outline"
                    >
                      {choice}
                    </Button>
                  ))}
                </div>

                <p className="mt-4 text-center text-xs leading-5 text-thai-cream/55">
                  ตอบถูก = ลด Rage บอส / ตอบผิด = บอสสวนกลับทันที
                </p>
              </div>
            </motion.div>
          )}

          {status === "feedback" && feedback && (
            <motion.div
              initial={{ opacity: 0, y: 80 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 80 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-5"
            >
              <div
                className={`w-full rounded-2xl border-2 p-5 shadow-2xl ${
                  feedback.tone === "correct"
                    ? "border-green-400 bg-emerald-950"
                    : "border-red-400 bg-red-950"
                }`}
              >
                <h2
                  className={`mb-2 text-center text-2xl font-bold ${
                    feedback.tone === "correct"
                      ? "text-green-300"
                      : "text-red-300"
                  }`}
                >
                  {feedback.title}
                </h2>

                <p className="text-center text-sm leading-6 text-thai-cream/85">
                  {feedback.message}
                </p>

                {feedback.fact && (
                  <div className="mt-4 rounded-xl border border-thai-gold/25 bg-black/35 p-4">
                    <h3 className="mb-1 font-bold text-thai-gold">
                      เกร็ดความรู้
                    </h3>

                    <p className="text-sm leading-6 text-thai-cream/80">
                      {feedback.fact}
                    </p>
                  </div>
                )}

                <div className="mt-5">
                  <Button onClick={continueBattle}>
                    สู้ต่อ
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {(status === "won" || status === "lost") && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-5 text-center"
            >
              <motion.div
                initial={{ y: 24, scale: 0.95 }}
                animate={{ y: 0, scale: 1 }}
                className="w-full rounded-2xl border-2 border-thai-gold bg-thai-dark p-6 shadow-2xl"
              >
                <h2 className="mb-3 text-3xl font-bold text-thai-gold">
                  {status === "won" ? "บอสล้มแล้ว!" : "พ่ายแพ้ต่อสมุทร"}
                </h2>

                <p className="mb-5 text-sm leading-7 text-thai-cream/80">
                  {status === "won"
                    ? "เสียงปี่วิเศษสยบความโกรธของผีเสื้อสมุทรได้สำเร็จ พระอภัยมณีรอดพ้นจากสมุทรคลั่ง"
                    : "พระอภัยมณีพลาดจังหวะสุดท้าย และถูกคลื่นสมุทรกลืนหายไป"}
                </p>

                <div className="mb-5 rounded-xl border border-thai-gold/20 bg-black/35 p-4 text-sm text-thai-cream/80">
                  <p>คะแนนจากบอส: {battleScore}</p>
                  <p>HP คงเหลือ: {Math.max(0, playerHP)}</p>
                </div>

                <Button onClick={() => router.push("/result")}>
                  ดูผลลัพธ์สุดท้าย
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </Screen>
  );
}
