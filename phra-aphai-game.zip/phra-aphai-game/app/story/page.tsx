"use client";

import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Button from "@/components/Button";
import SceneCard from "@/components/SceneCard";
import Screen from "@/components/Screen";

export default function StoryPage() {
  const router = useRouter();

  return (
    <Screen className="justify-center bg-gradient-to-b from-slate-950 via-thai-dark to-black p-5">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          animate={{ x: [0, 20, 0], opacity: [0.2, 0.35, 0.2] }}
          transition={{ repeat: Infinity, duration: 5 }}
          className="absolute left-[-70px] top-10 h-52 w-52 rounded-full bg-blue-500/20 blur-3xl"
        />
        <motion.div
          animate={{ x: [0, -18, 0], opacity: [0.15, 0.3, 0.15] }}
          transition={{ repeat: Infinity, duration: 6 }}
          className="absolute bottom-[-20px] right-[-70px] h-56 w-56 rounded-full bg-thai-gold/20 blur-3xl"
        />
      </div>

      <SceneCard title="บทนำ" className="relative z-10">
        <div className="space-y-4 text-lg leading-8 text-thai-cream">
          <p>
            พระอภัยมณีถูกจองจำอยู่ในถ้ำสมุทรมานาน
            บัดนี้ถึงเวลาต้องหลบหนีออกจากเงื้อมมือของผีเสื้อสมุทร
          </p>

          <p>
            ครอบครัวเงือกอาสาพาฝ่าคลื่นทะเลไปยังเกาะแก้วพิสดาร
            แต่เสียงคำรามของผีเสื้อสมุทรดังไล่หลังมาอย่างน่ากลัว
          </p>

          <p>
            ทางรอดเดียวคือใช้ไหวพริบ ความรู้ภาษาไทย
            และพลังจากเสียงปี่วิเศษ เพื่อเอาชีวิตรอดจากสมุทรคลั่ง
          </p>
        </div>

        <div className="mt-7 rounded-xl border border-thai-gold/25 bg-thai-gold/10 p-4">
          <h3 className="mb-2 font-bold text-thai-gold">ภารกิจของคุณ</h3>

          <ul className="list-disc space-y-2 pl-5 text-sm leading-6 text-thai-cream/85">
            <li>ว่ายน้ำหลบสิ่งกีดขวางในถ้ำสมุทร</li>
            <li>เรียงคำกลอนให้ถูกต้องเพื่อรับพลังพิเศษ</li>
            <li>ตอบคำถามวรรณคดีไทยเพื่อสยบผีเสื้อสมุทร</li>
          </ul>
        </div>

        <div className="mt-7 space-y-3">
          <Button onClick={() => router.push("/game/escape")} variant="primary">
            เริ่มด่านที่ 1: หนีถ้ำสมุทร
          </Button>

          <Button onClick={() => router.push("/")} variant="outline">
            กลับหน้าแรก
          </Button>
        </div>
      </SceneCard>
    </Screen>
  );
}
