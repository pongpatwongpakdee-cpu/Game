"use client";

import { motion } from "framer-motion";

interface SceneCardProps {
  title: string;
  children: React.ReactNode;
  className?: string;
}

export default function SceneCard({
  title,
  children,
  className = "",
}: SceneCardProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 24, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5 }}
      className={`rounded-2xl border border-thai-gold/50 bg-black/55 p-5 shadow-2xl backdrop-blur-md ${className}`}
    >
      <h2 className="mb-4 text-center text-2xl font-bold text-thai-gold">
        {title}
      </h2>

      {children}
    </motion.section>
  );
}
