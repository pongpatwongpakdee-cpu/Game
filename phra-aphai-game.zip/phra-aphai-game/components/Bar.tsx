"use client";

import { motion } from "framer-motion";

interface BarProps {
  value: number;
  max: number;
  colorClass: string;
  label: string;
}

export default function Bar({ value, max, colorClass, label }: BarProps) {
  const safeValue = Math.max(0, Math.min(value, max));
  const percentage = Math.max(0, Math.min(100, (safeValue / max) * 100));

  return (
    <div className="w-full">
      <div className="mb-1 flex justify-between text-sm text-thai-cream">
        <span>{label}</span>
        <span>
          {Math.floor(safeValue)}/{max}
        </span>
      </div>

      <div className="h-4 w-full overflow-hidden rounded-full border border-thai-gold/30 bg-black/60">
        <motion.div
          className={`h-full ${colorClass}`}
          initial={{ width: "100%" }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.25 }}
        />
      </div>
    </div>
  );
}
