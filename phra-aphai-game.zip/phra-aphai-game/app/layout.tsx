import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ศึกพระอภัยมณี: หนีถ้ำสมุทร",
  description: "เกมการศึกษา วันสุนทรภู่ × วันภาษาไทย",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th">
      <body className="bg-black text-white antialiased">
        <div className="mx-auto flex h-[100dvh] max-w-md flex-col overflow-hidden border-x border-thai-gold/20 bg-thai-dark font-sans shadow-2xl">
          {children}
        </div>
      </body>
    </html>
  );
}
