"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Button from "@/components/Button";
import Screen from "@/components/Screen";
import { getGameState, resetGameState, saveGameState } from "@/lib/gameStorage";
import type { GameRank, GameState } from "@/types/game";

function getRank(score: number, bossDefeated: boolean): GameRank {
  if (score >= 1200 && bossDefeated) return "ตำนานพระอภัยมณี";
  if (score >= 800) return "ผู้ใช้ปี่วิเศษ";
  if (score >= 450) return "ศิษย์กวี";
  return "นักเดินเรือฝึกหัด";
}

function getRankDescription(rank: GameRank) {
  switch (rank) {
    case "ตำนานพระอภัยมณี":
      return "คุณผ่านสมุทรคลั่ง ตอบคำถามได้ดี และสยบบอสได้อย่างสง่างาม";
    case "ผู้ใช้ปี่วิเศษ":
      return "คุณเข้าใจวรรณคดีไทยดีพอจะใช้เสียงปี่เป็นพลังต่อสู้";
    case "ศิษย์กวี":
      return "คุณมีพื้นฐานดี แต่ยังฝึกความแม่นยำเรื่องภาษาไทยได้อีก";
    case "นักเดินเรือฝึกหัด":
      return "คุณยังอยู่ช่วงเริ่มต้น แต่ถือว่าได้เปิดประตูสู่วรรณคดีไทยแล้ว";
  }
}

function getDifficultyLabel(mode: GameState["difficultyMode"]) {
  if (mode === "easy") return "ง่าย";
  if (mode === "hard") return "ยาก";
  return "ปกติ";
}

export default function ResultPage() {
  const router = useRouter();

  const [state, setState] = useState<GameState | null>(null);

  useEffect(() => {
    const currentState = getGameState();
    const rank = getRank(currentState.score, currentState.bossDefeated);

    const updatedState = saveGameState({
      rank,
    });

    setState(updatedState);
  }, []);

  const accuracy = useMemo(() => {
    if (!state) return 0;

    const totalAnswers = state.correctAnswers + state.wrongAnswers;

    if (totalAnswers === 0) return 0;

    return Math.round((state.correctAnswers / totalAnswers) * 100);
  }, [state]);

  const totalAnswers = useMemo(() => {
    if (!state) return 0;

    return state.correctAnswers + state.wrongAnswers;
  }, [state]);

  const handlePlayAgain = () => {
    resetGameState();
    router.push("/");
  };

  if (!state) {
    return (
      <Screen className="items-center justify-center bg-thai-dark p-6">
        <p className="text-thai-cream">กำลังสรุปผล...</p>
      </Screen>
    );
  }

  const rank: GameRank = state.rank || getRank(state.score, state.bossDefeated);

  return (
    <Screen scrollable className="bg-gradient-to-b from-black via-thai-dark to-slate-950 p-5">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          animate={{ opacity: [0.18, 0.34, 0.18], scale: [1, 1.12, 1] }}
          transition={{ repeat: Infinity, duration: 5 }}
          className="absolute left-[-90px] top-10 h-64 w-64 rounded-full bg-thai-gold/20 blur-3xl"
        />

        <motion.div
          animate={{ opacity: [0.14, 0.3, 0.14], scale: [1, 1.16, 1] }}
          transition={{ repeat: Infinity, duration: 6 }}
          className="absolute bottom-[-80px] right-[-80px] h-72 w-72 rounded-full bg-blue-400/20 blur-3xl"
        />
      </div>

      <motion.section
        initial={{ opacity: 0, y: 28, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 my-6 w-full rounded-3xl border-2 border-thai-gold bg-black/60 p-5 shadow-[0_0_50px_rgba(212,175,55,0.22)] backdrop-blur-md"
      >
        <div className="mb-5 text-center">
          <p className="mb-1 text-sm font-medium text-thai-gold">
            ใบประกาศการผจญภัย
          </p>

          <h1 className="text-3xl font-bold text-thai-cream">
            ศึกพระอภัยมณี
          </h1>

          <p className="mt-1 text-xs text-thai-cream/55">
            วันสุนทรภู่ × วันภาษาไทย
          </p>
        </div>

        <div
          className={`mb-5 rounded-2xl border p-4 text-center ${
            state.bossDefeated
              ? "border-green-400/40 bg-emerald-950/35"
              : "border-red-400/40 bg-red-950/35"
          }`}
        >
          <p
            className={`mb-1 text-sm font-bold ${
              state.bossDefeated ? "text-green-300" : "text-red-300"
            }`}
          >
            {state.bossDefeated ? "ภารกิจสำเร็จ" : "ภารกิจยังไม่สำเร็จ"}
          </p>

          <h2 className="text-5xl font-bold text-thai-gold">
            {state.score}
          </h2>

          <p className="mt-1 text-sm text-thai-cream/70">คะแนนรวม</p>
        </div>

        <div className="mb-5 rounded-2xl border border-thai-gold/30 bg-thai-gold/10 p-4 text-center">
          <p className="mb-1 text-xs text-thai-cream/60">ยศที่ได้รับ</p>

          <h3 className="text-2xl font-bold text-thai-gold">{rank}</h3>

          <p className="mt-2 text-sm leading-6 text-thai-cream/75">
            {getRankDescription(rank)}
          </p>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
            <p className="text-xs text-thai-cream/50">โหมด</p>
            <p className="mt-1 font-bold text-thai-cream">
              {getDifficultyLabel(state.difficultyMode)}
            </p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
            <p className="text-xs text-thai-cream/50">Accuracy</p>
            <p className="mt-1 font-bold text-thai-cream">{accuracy}%</p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
            <p className="text-xs text-thai-cream/50">ตอบถูก</p>
            <p className="mt-1 font-bold text-green-300">
              {state.correctAnswers}
            </p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
            <p className="text-xs text-thai-cream/50">ตอบผิด</p>
            <p className="mt-1 font-bold text-red-300">
              {state.wrongAnswers}
            </p>
          </div>
        </div>

        <div className="mb-5 rounded-2xl border border-thai-gold/20 bg-black/35 p-4">
          <h3 className="mb-3 font-bold text-thai-gold">ภารกิจ</h3>

          <div className="space-y-2 text-sm text-thai-cream/80">
            <div className="flex items-center justify-between">
              <span>หนีถ้ำสมุทร</span>
              <span
                className={
                  state.escapeCompleted ? "text-green-300" : "text-red-300"
                }
              >
                {state.escapeCompleted ? "สำเร็จ" : "ไม่สำเร็จ"}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span>เรียงคำกลอน</span>
              <span
                className={state.poemBonus > 0 ? "text-green-300" : "text-red-300"}
              >
                {state.poemBonus > 0 ? "ผ่าน" : "ยังไม่ผ่าน"}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span>สู้ผีเสื้อสมุทร</span>
              <span
                className={state.bossDefeated ? "text-green-300" : "text-red-300"}
              >
                {state.bossDefeated ? "ชนะ" : "แพ้"}
              </span>
            </div>
          </div>
        </div>

        <div className="mb-5 rounded-2xl border border-thai-gold/20 bg-black/35 p-4">
          <h3 className="mb-2 font-bold text-thai-gold">
            ความรู้ที่ได้จากเกม
          </h3>

          <ul className="list-disc space-y-2 pl-5 text-sm leading-6 text-thai-cream/75">
            <li>พระอภัยมณีใช้ปี่เป็นอาวุธสำคัญในการต่อสู้และสะกดศัตรู</li>
            <li>ครอบครัวเงือกมีบทบาทสำคัญในการช่วยพระอภัยมณีหนีจากถ้ำ</li>
            <li>วันสุนทรภู่ตรงกับวันที่ 26 มิถุนายนของทุกปี</li>
            <li>การใช้ภาษาไทยที่ดีต้องคำนึงถึงความหมาย ความเหมาะสม และกาลเทศะ</li>
          </ul>

          {totalAnswers === 0 && (
            <p className="mt-3 rounded-lg bg-thai-gold/10 p-3 text-xs leading-5 text-thai-cream/65">
              รอบนี้ยังไม่มีสถิติคำถามมากนัก ลองเล่นใหม่ให้ครบทุกด่านเพื่อวัดคะแนนจริง
            </p>
          )}
        </div>

        <div className="space-y-3">
          <Button onClick={handlePlayAgain}>เล่นใหม่</Button>

          <Button onClick={() => router.push("/")} variant="outline">
            กลับหน้าแรก
          </Button>
        </div>
      </motion.section>
    </Screen>
  );
}
