"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Button from "@/components/Button";
import Screen from "@/components/Screen";
import { resetGameState } from "@/lib/gameStorage";

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    resetGameState();
  }, []);

  return (
    <Screen className="items-center justify-center bg-ocean-noise p-6">
      <div className="pointer-events-none absolute inset-0 opacity-30">
        <div className="absolute left-[-80px] top-20 h-48 w-48 rounded-full bg-thai-gold/20 blur-3xl" />
        <div className="absolute bottom-10 right-[-80px] h-56 w-56 rounded-full bg-blue-400/20 blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 26 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55 }}
        className="relative z-10 flex w-full flex-col items-center text-center"
      >
        <motion.div
          animate={{ y: [0, -8, 0] }}
          transition={{ repeat: Infinity, duration: 2.8, ease: "easeInOut" }}
          className="mb-6 flex h-28 w-28 items-center justify-center rounded-full border-4 border-thai-gold bg-black/40 text-5xl shadow-[0_0_40px_rgba(212,175,55,0.35)]"
        >
          🌊
        </motion.div>

        <p className="mb-2 text-lg font-medium text-thai-gold">
          วันสุนทรภู่ × วันภาษาไทย
        </p>

        <h1 className="text-glow-gold mb-4 text-5xl font-bold leading-tight text-thai-cream">
          ศึกพระอภัยมณี
          <br />
          <span className="text-3xl text-blue-200">หนีถ้ำสมุทร</span>
        </h1>

        <p className="mb-9 max-w-[300px] text-sm leading-6 text-thai-cream/80">
          ผจญภัยฝ่าคลื่น ตอบคำถามวรรณคดีไทย เรียงคำกลอน
          และใช้เสียงปี่วิเศษสยบความโกรธของผีเสื้อสมุทร
        </p>

        <div className="w-full max-w-[280px] space-y-3">
          <Button onClick={() => router.push("/story")}>
            เริ่มการผจญภัย
          </Button>

          <Button
            onClick={() => router.push("/how-to-play")}
            variant="outline"
          >
            วิธีเล่น
          </Button>
        </div>

        <p className="mt-6 text-xs text-thai-cream/50">
          เล่นได้บนมือถือ แท็บเล็ต และคอมพิวเตอร์
        </p>
      </motion.div>
    </Screen>
  );
}
