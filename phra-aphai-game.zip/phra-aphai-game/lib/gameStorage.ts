import type { GameState } from "@/types/game";
import { DEFAULT_GAME_STATE, STORAGE_KEY } from "@/lib/gameConstants";

export function getGameState(): GameState {
  if (typeof window === "undefined") {
    return { ...DEFAULT_GAME_STATE };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);

    if (!raw) {
      return { ...DEFAULT_GAME_STATE };
    }

    return {
      ...DEFAULT_GAME_STATE,
      ...JSON.parse(raw),
    };
  } catch {
    return { ...DEFAULT_GAME_STATE };
  }
}

export function saveGameState(nextState: Partial<GameState>): GameState {
  const currentState = getGameState();

  const updatedState: GameState = {
    ...currentState,
    ...nextState,
  };

  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedState));
  }

  return updatedState;
}

export function resetGameState(): GameState {
  const freshState: GameState = { ...DEFAULT_GAME_STATE };

  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(freshState));
  }

  return freshState;
}

export function addScore(points: number): GameState {
  const currentState = getGameState();

  return saveGameState({
    score: Math.max(0, currentState.score + points),
  });
}
