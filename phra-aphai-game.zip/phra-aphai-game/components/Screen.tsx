interface ScreenProps {
  children: React.ReactNode;
  className?: string;
  scrollable?: boolean;
}

export default function Screen({
  children,
  className = "",
  scrollable = false,
}: ScreenProps) {
  return (
    <main
      className={`game-safe-area relative flex min-h-0 flex-1 flex-col ${
        scrollable ? "overflow-y-auto overflow-x-hidden" : "overflow-hidden"
      } ${className}`}
    >
      {children}
    </main>
  );
}
