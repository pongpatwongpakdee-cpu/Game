export type GameRank =
  | "ตำนานพระอภัยมณี"
  | "ผู้ใช้ปี่วิเศษ"
  | "ศิษย์กวี"
  | "นักเดินเรือฝึกหัด";

export type DifficultyMode = "easy" | "normal" | "hard";

export interface GameState {
  score: number;
  rank: GameRank | "";
  escapeCompleted: boolean;
  poemBonus: number;
  bossDefeated: boolean;
  correctAnswers: number;
  wrongAnswers: number;
  totalPlayTime: number;
  difficultyMode: DifficultyMode;
}

export interface Question {
  id: number;
  question: string;
  choices: string[];
  correctAnswer: number;
  fact: string;
  difficulty: "easy" | "medium" | "hard";
}

export interface PoemFragment {
  id: number;
  title: string;
  scrambled: string[];
  correct: string[];
  explanation: string;
}

export type EscapeEntityType = "rock" | "wave" | "shadow" | "heal" | "quiz";

export interface EscapeEntity {
  id: number;
  lane: number;
  x: number;
  speed: number;
  type: EscapeEntityType;
}
