"use client";

import { motion } from "framer-motion";

interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  variant?: "primary" | "danger" | "outline" | "blue";
  className?: string;
  disabled?: boolean;
}

export default function Button({
  onClick,
  children,
  variant = "primary",
  className = "",
  disabled = false,
}: ButtonProps) {
  const baseStyle =
    "w-full py-3 px-6 rounded-xl text-lg font-bold shadow-lg flex items-center justify-center transition-all select-none";

  const variants = {
    primary:
      "bg-gradient-to-r from-thai-gold to-yellow-600 text-thai-dark active:brightness-110",
    danger:
      "bg-gradient-to-r from-red-600 to-thai-blood text-white active:brightness-110",
    outline:
      "border-2 border-thai-gold text-thai-gold bg-black/20 active:bg-thai-gold active:text-thai-dark",
    blue:
      "bg-gradient-to-r from-thai-ocean to-blue-700 text-white active:brightness-110",
  };

  const disabledStyle = disabled
    ? "opacity-40 pointer-events-none grayscale"
    : "";

  return (
    <motion.button
      type="button"
      whileTap={disabled ? undefined : { scale: 0.95 }}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyle} ${variants[variant]} ${disabledStyle} ${className}`}
    >
      {children}
    </motion.button>
  );
}
