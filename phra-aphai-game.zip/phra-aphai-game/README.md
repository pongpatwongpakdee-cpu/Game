# ศึกพระอภัยมณี: หนีถ้ำสมุทร

เกมการศึกษาแนว Mobile-First สำหรับงานวันสุนทรภู่ × วันภาษาไทย  
สร้างด้วย Next.js 15, TypeScript, Tailwind CSS และ Framer Motion

เกมนี้ออกแบบให้เล่นได้บน:

- iPad
- iPhone
- Android
- Desktop Browser

ไม่ต้อง Login  
ไม่ต้อง Database  
เก็บคะแนนด้วย Local Storage

---

## 1. Tech Stack

- Next.js 15
- React
- TypeScript
- Tailwind CSS
- Framer Motion
- Local Storage

---

## 2. วิธีติดตั้ง

แตกไฟล์ ZIP แล้วเปิด Terminal ในโฟลเดอร์โปรเจกต์ จากนั้นรัน:

```bash
npm install
```

---

## 3. วิธีรันเกม

```bash
npm run dev
```

จากนั้นเปิด:

```txt
http://localhost:3000
```

---

## 4. วิธี Build สำหรับใช้งานจริง

```bash
npm run build
npm run start
```

ถ้าจะเอาขึ้น Vercel ให้ใช้:

```bash
npm run build
```

ถ้า build ผ่าน ก็นำขึ้น Vercel ได้เลย

---

## 5. โครงสร้างไฟล์หลัก

```txt
app/
  page.tsx
  layout.tsx
  globals.css

  story/
    page.tsx

  how-to-play/
    page.tsx

  game/
    escape/
      page.tsx
    poem/
      page.tsx
    boss/
      page.tsx

  result/
    page.tsx

components/
  Button.tsx
  Bar.tsx
  Screen.tsx
  SceneCard.tsx

data/
  questions.ts

lib/
  gameConstants.ts
  gameStorage.ts

types/
  game.ts

README.md
```

---

## 6. Flow ของเกม

```txt
หน้าแรก
↓
เนื้อเรื่อง
↓
ด่าน 1: หนีถ้ำสมุทร
↓
ด่าน 2: เรียงคำกลอน
↓
ด่าน 3: สู้ผีเสื้อสมุทร
↓
หน้าสรุปผล
```

---

## 7. ด่านที่ 1: หนีถ้ำสมุทร

ผู้เล่นสวมบทบาทเป็นนางเงือก  
ต้องว่ายน้ำหลบสิ่งกีดขวาง 3 เลน

ระบบในด่านนี้:

- เลือกโหมดง่าย / ปกติ / ยาก
- สิ่งกีดขวางมีความเร็วต่างกัน
- ไอเทมฟื้นพลัง
- คำถามสุ่มระหว่างหนี
- คอมโบหลบต่อเนื่อง
- ชนแล้วเสีย HP
- หนีครบ 100% ถึงจะผ่าน

---

## 8. ด่านที่ 2: เรียงคำกลอน

ผู้เล่นต้องเรียงคำให้ถูกต้อง  
ถ้าตอบถูกจะได้รับ:

- คะแนนโบนัส
- โบนัส HP สำหรับด่านบอส

แก้โจทย์คำกลอนได้ที่:

```txt
data/questions.ts
```

ในตัวแปร:

```ts
poemFragments
```

ตัวอย่าง:

```ts
{
  id: 1,
  title: "เรียงคำกลอนสุภาษิต",
  scrambled: ["พูด", "ถึงบาง", "ดีเป็น", "ศรีศักดิ์", "พูด"],
  correct: ["ถึงบาง", "พูด", "พูด", "ดีเป็น", "ศรีศักดิ์"],
  explanation: "วรรคนี้สื่อถึงคุณค่าของการพูดดี",
}
```

---

## 9. ด่านที่ 3: สู้ผีเสื้อสมุทร

เป็น Boss Fight แบบ Phase Battle

ระบบในด่านนี้:

- Boss Phase 1 / 2 / 3
- ตอบคำถามถูก = ลด Rage บอส
- ตอบคำถามผิด = โดนบอสสวน
- ตั้งรับ = ลดดาเมจ
- รวบรวมลมหายใจ = ฟื้น HP แต่บอสโจมตีฟรี
- มี Battle Log
- มี Fact ความรู้หลังตอบคำถาม

---

## 10. วิธีแก้คำถาม

เปิดไฟล์:

```txt
data/questions.ts
```

เพิ่มคำถามในตัวแปร:

```ts
questions
```

ตัวอย่าง:

```ts
{
  id: 7,
  question: "วันสุนทรภู่ตรงกับวันที่เท่าไร?",
  choices: ["24 มิถุนายน", "25 มิถุนายน", "26 มิถุนายน", "27 มิถุนายน"],
  correctAnswer: 2,
  difficulty: "easy",
  fact: "วันสุนทรภู่ตรงกับวันที่ 26 มิถุนายนของทุกปี",
}
```

หมายเหตุ:

```txt
correctAnswer ใช้เลข index เริ่มจาก 0
```

ตัวอย่าง:

```txt
choices[0] = ตัวเลือกแรก
choices[1] = ตัวเลือกที่สอง
choices[2] = ตัวเลือกที่สาม
choices[3] = ตัวเลือกที่สี่
```

ดังนั้นถ้าคำตอบคือข้อ 3 ให้ใส่:

```ts
correctAnswer: 2
```

---

## 11. วิธีแก้ความยากของเกม

เปิดไฟล์:

```txt
lib/gameConstants.ts
```

แก้ค่าตรงนี้:

```ts
GAME_CONFIG.escape.modes
```

ตัวอย่างค่าที่แก้ได้:

```txt
maxHP = เลือดผู้เล่น
distancePerTick = ความเร็วในการหนี
spawnMs = ความถี่สิ่งกีดขวาง
baseSpeed = ความเร็วสิ่งกีดขวาง
hitDamage = ดาเมจเมื่อชน
healAmount = จำนวน HP ที่ฟื้น
healChance = โอกาสเกิดไอเทมฟื้นพลัง
quizChance = โอกาสเกิดคำถาม
```

---

## 12. วิธีแก้ค่าบอส

เปิดไฟล์:

```txt
app/game/boss/page.tsx
```

แก้ค่าตรงนี้:

```ts
const BOSS_MAX_RAGE = 300;
```

และตรงนี้:

```ts
PHASE_CONFIG
```

ค่าที่แก้ได้:

```txt
correctDamage = ดาเมจจากการตอบถูก
attackDamage = ดาเมจที่บอสโจมตี
attackName = ชื่อท่าโจมตี
quote = คำพูดบอส
```

---

## 13. วิธี Reset คะแนน

คะแนนเก็บใน Local Storage key:

```txt
phraAphaiState
```

ถ้าอยากล้างเองใน Browser:

1. เปิด DevTools
2. ไปที่ Application
3. เลือก Local Storage
4. ลบ key ชื่อ `phraAphaiState`

หรือกดปุ่ม “เล่นใหม่” ในเกมก็ได้

---

## 14. ปัญหาที่อาจเจอ

### 14.1 ปุ่มกดไม่ได้

เช็กว่าไฟล์ `Button.tsx` มี prop นี้หรือยัง:

```ts
disabled?: boolean;
```

### 14.2 หน้า Result เลื่อนไม่ได้

เช็กว่า `components/Screen.tsx` รองรับ:

```ts
scrollable?: boolean;
```

และหน้า Result ใช้:

```tsx
<Screen scrollable ...>
```

### 14.3 Tailwind ไม่เจอสี `thai-gold`

เช็กไฟล์:

```txt
tailwind.config.ts
```

ต้องมี:

```ts
colors: {
  thai: {
    gold: "#D4AF37",
    dark: "#0F172A",
    ocean: "#0369A1",
    cream: "#FEF3C7",
    blood: "#7F1D1D",
    jade: "#14B8A6",
  },
}
```

### 14.4 Import `@/components/...` ใช้ไม่ได้

เช็กว่า `tsconfig.json` มี alias:

```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./*"]
    }
  }
}
```

---

## 15. Checklist ก่อนส่งงาน

ก่อนส่งงาน ให้เช็ก:

```txt
[ ] npm install แล้ว
[ ] npm run dev เปิดได้
[ ] หน้าแรกเข้าได้
[ ] ปุ่มเริ่มเกมใช้ได้
[ ] ด่านหนีเล่นได้
[ ] ด่านเรียงคำกลอนเล่นได้
[ ] ด่านบอสเล่นได้
[ ] หน้า Result แสดงคะแนน
[ ] กดเล่นใหม่แล้ว Reset คะแนน
[ ] npm run build ผ่าน
```

---

## 16. คำอธิบายโปรเจกต์แบบสั้น

เกม “ศึกพระอภัยมณี: หนีถ้ำสมุทร” เป็นเกมการศึกษาเกี่ยวกับวรรณคดีไทย  
ผู้เล่นจะได้เรียนรู้เรื่องสุนทรภู่ พระอภัยมณี และการใช้ภาษาไทย  
ผ่านเกม 3 รูปแบบ ได้แก่ เกมหลบหลีก เกมเรียงคำ และเกมตอบคำถามสู้บอส

---

## 17. คำอธิบายโปรเจกต์สำหรับนำเสนอครู

โปรเจกต์นี้จัดทำขึ้นเพื่อส่งเสริมการเรียนรู้วรรณคดีไทยในรูปแบบเกม  
โดยนำเนื้อหาจากเรื่องพระอภัยมณีมาประยุกต์กับเกมแนวผจญภัย  
ผู้เล่นจะได้เรียนรู้ผ่านการลงมือเล่น ตอบคำถาม เรียงคำกลอน  
และตัดสินใจระหว่างการต่อสู้กับตัวละครสำคัญอย่างผีเสื้อสมุทร

จุดเด่นของเกมคือออกแบบให้เล่นง่ายบน iPad, โทรศัพท์มือถือ และคอมพิวเตอร์  
ไม่ต้องสมัครสมาชิก ไม่ต้องใช้ฐานข้อมูล และสามารถเล่นได้ผ่าน Web Browser
