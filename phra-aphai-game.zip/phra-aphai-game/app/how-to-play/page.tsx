"use client";

import { useRouter } from "next/navigation";
import Button from "@/components/Button";
import SceneCard from "@/components/SceneCard";
import Screen from "@/components/Screen";

export default function HowToPlayPage() {
  const router = useRouter();

  return (
    <Screen className="justify-center bg-gradient-to-b from-thai-dark to-black p-5">
      <SceneCard title="วิธีเล่น">
        <div className="space-y-5 text-thai-cream">
          <div>
            <h3 className="mb-1 text-lg font-bold text-thai-gold">
              ด่านที่ 1: หนีถ้ำสมุทร
            </h3>
            <p className="text-sm leading-6 text-thai-cream/80">
              แตะปุ่มขึ้นหรือลงเพื่อย้ายเลน หลบหิน คลื่น และเงามืด
              หากชนสิ่งกีดขวาง พลังชีวิตจะลดลง
            </p>
          </div>

          <div>
            <h3 className="mb-1 text-lg font-bold text-thai-gold">
              ด่านที่ 2: เรียงคำกลอน
            </h3>
            <p className="text-sm leading-6 text-thai-cream/80">
              เลือกคำให้เรียงเป็นวรรคกลอนที่ถูกต้อง
              หากตอบถูกจะได้รับโบนัสพลังชีวิตสำหรับด่านบอส
            </p>
          </div>

          <div>
            <h3 className="mb-1 text-lg font-bold text-thai-gold">
              ด่านที่ 3: สู้ผีเสื้อสมุทร
            </h3>
            <p className="text-sm leading-6 text-thai-cream/80">
              ตอบคำถามเกี่ยวกับสุนทรภู่และพระอภัยมณี
              ตอบถูกจะลดความโกรธของบอส ตอบผิดจะเสียพลังชีวิต
            </p>
          </div>
        </div>

        <div className="mt-7 space-y-3">
          <Button onClick={() => router.push("/story")}>
            ไปหน้าเนื้อเรื่อง
          </Button>

          <Button onClick={() => router.push("/")} variant="outline">
            กลับหน้าแรก
          </Button>
        </div>
      </SceneCard>
    </Screen>
  );
}
